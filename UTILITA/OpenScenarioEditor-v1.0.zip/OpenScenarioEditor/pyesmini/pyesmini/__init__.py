"""
pyesmini
~~~~~~
Python wrapper for esmini
"""
